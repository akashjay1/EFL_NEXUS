"""
Updater for MyDataTool
Usage: updater.exe --url <download_url> --version <new_version> --pid <main_pid> --appdir <app_directory>
"""

import sys
import os
import time
import shutil
import subprocess
import tempfile
import zipfile
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import requests

# ----------------------------------------------------------------------
# Parse command line arguments
# ----------------------------------------------------------------------
def parse_args():
    args = {}
    for i, arg in enumerate(sys.argv):
        if arg.startswith("--"):
            key = arg[2:]
            if i + 1 < len(sys.argv) and not sys.argv[i+1].startswith("--"):
                args[key] = sys.argv[i+1]
    return args

# ----------------------------------------------------------------------
# GUI updater
# ----------------------------------------------------------------------
class UpdaterApp:
    def __init__(self, root, url, new_version, pid, app_dir):
        self.root = root
        self.url = url
        self.new_version = new_version
        self.pid = pid
        self.app_dir = app_dir
        self.temp_dir = None
        self.download_path = None

        root.title("Update MyDataTool")
        root.geometry("500x220")
        root.resizable(False, False)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

        # --- UI ---
        main = ttk.Frame(root, padding="20")
        main.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main, text=f"Update to version {new_version}", font=("Segoe UI", 12, "bold")).pack(pady=(0, 10))
        self.status_var = tk.StringVar(value="Preparing update...")
        ttk.Label(main, textvariable=self.status_var).pack()

        self.progress = ttk.Progressbar(main, mode='determinate', maximum=100)
        self.progress.pack(fill=tk.X, pady=(15, 10))

        self.button = ttk.Button(main, text="Cancel", command=self.on_close)
        self.button.pack(pady=5)

        # Start update in background thread
        threading.Thread(target=self.do_update, daemon=True).start()

    def on_close(self):
        """User pressed Cancel – if not started yet, allow close."""
        if self.download_path is None:
            self.root.destroy()
        else:
            messagebox.showinfo("Update in progress", "The update is already running and cannot be cancelled.")

    def update_status(self, msg, value=None):
        self.status_var.set(msg)
        if value is not None:
            self.progress['value'] = value
        self.root.update_idletasks()

    def do_update(self):
        try:
            # 1. Download the zip
            self.update_status("Downloading update...", 0)
            self.download_path = self.download_file(self.url)
            self.update_status("Download complete.", 30)

            # 2. Extract to temp folder
            self.update_status("Extracting files...", 40)
            self.temp_dir = tempfile.mkdtemp()
            with zipfile.ZipFile(self.download_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            self.update_status("Extraction complete.", 60)

            # 3. Terminate the main app
            self.update_status("Closing the main application...", 70)
            self.terminate_main_app()

            # 4. Copy new files over
            self.update_status("Installing new files...", 80)
            self.copy_new_files()

            # 5. Update local version.txt
            self.update_status("Updating version file...", 90)
            with open(os.path.join(self.app_dir, "version.txt"), "w") as f:
                f.write(self.new_version.strip())

            # 6. Restart the main app
            self.update_status("Starting the updated application...", 100)
            self.restart_main_app()

            # 7. Close updater
            self.root.after(0, self.root.destroy)

        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Update failed", str(e)))
            self.root.after(0, self.root.destroy)

    def download_file(self, url):
        """Download the zip file with progress."""
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()
            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded = 0

            fd, path = tempfile.mkstemp(suffix='.zip')
            with os.fdopen(fd, 'wb') as f:
                for chunk in response.iter_content(chunk_size=block_size):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size:
                            progress = 30 * (downloaded / total_size)
                            self.progress['value'] = progress
                            self.root.update_idletasks()
            return path
        except Exception as e:
            raise Exception(f"Download failed: {e}")

    def terminate_main_app(self):
        """Terminate the process with the given PID."""
        if not self.pid:
            subprocess.run(['taskkill', '/F', '/IM', 'MyDataTool.exe'], capture_output=True)
            return
        try:
            subprocess.run(['taskkill', '/F', '/PID', str(self.pid)], capture_output=True)
            time.sleep(1)
        except Exception:
            pass  # process may already be gone

    def copy_new_files(self):
        """Copy all files from temp_dir to app_dir, overwriting existing."""
        if not os.path.exists(self.app_dir):
            os.makedirs(self.app_dir)
        for item in os.listdir(self.temp_dir):
            src = os.path.join(self.temp_dir, item)
            dst = os.path.join(self.app_dir, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)

    def restart_main_app(self):
        """Launch the main application."""
        main_exe = os.path.join(self.app_dir, "MyDataTool.exe")
        if os.path.exists(main_exe):
            subprocess.Popen([main_exe], cwd=self.app_dir)
        else:
            raise Exception("MyDataTool.exe not found after update.")

# ----------------------------------------------------------------------
# Main entry point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    args = parse_args()
    url = args.get('url')
    new_version = args.get('version')
    pid = args.get('pid')
    app_dir = args.get('appdir')

    if not url or not new_version or not app_dir:
        print("Usage: updater.exe --url <download_url> --version <version> --pid <pid> --appdir <app_dir>")
        sys.exit(1)

    try:
        pid = int(pid) if pid else None
    except ValueError:
        pid = None

    root = tk.Tk()
    app = UpdaterApp(root, url, new_version, pid, app_dir)
    root.mainloop()